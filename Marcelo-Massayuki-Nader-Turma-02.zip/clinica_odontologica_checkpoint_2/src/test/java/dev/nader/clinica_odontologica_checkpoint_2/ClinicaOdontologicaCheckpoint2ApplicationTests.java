package dev.nader.clinica_odontologica_checkpoint_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaOdontologicaCheckpoint2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
